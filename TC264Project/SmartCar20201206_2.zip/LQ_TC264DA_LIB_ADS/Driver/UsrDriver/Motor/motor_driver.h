/*
 * motor.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_MOTOR_MOTOR_DRIVER_H_
#define DRIVER_USRDRIVER_MOTOR_MOTOR_DRIVER_H_

#include "sys_driver.h"
typedef struct
{
      int I;
}motor_usr_extern_para_t;//para only for close cycle ctrl

typedef struct motor_ctrl
{
        unsigned char (*Init)(struct motor_ctrl *self);
        unsigned short (*SetSpeed)(struct motor_ctrl *self,signed short speed);
        signed short (*GetSpeed)(struct motor_ctrl *self);

        pwm_t *PwmDevice[2];
        enc_t *EncDevice;

        /*Motor Close Loop Control Function,It Support ReDefinition.*/
        unsigned short (*CtrlStrategy)(signed short target_speed,signed short actual_speed,motor_usr_extern_para_t *);

        signed short MaxSpeed;
        signed short MinSpeed;

        unsigned short PwmValue;

        bool Is_Run;

        struct motor_ctrl *Self;
        motor_usr_extern_para_t *Usr;

}motor_ctrl_t;

extern motor_ctrl_t Motor;

#endif /* DRIVER_USRDRIVER_MOTOR_MOTOR_DRIVER_H_ */
