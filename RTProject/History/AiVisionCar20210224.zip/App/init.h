/*
 * init.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INIT_H_
#define APP_INIT_H_

void Core0_HardWareInit();
void Core0_SoftWareInit();

void Core1_HardWareInit();
void Core1_SoftWareInit();

void Core2_HardWareInit();
void Core2_SoftWareInit();

#endif /* APP_INIT_H_ */
