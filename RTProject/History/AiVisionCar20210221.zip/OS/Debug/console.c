/*
 * console.c
 *
 *  Created on: 2021��1��16��
 *      Author: 936305695
 */
#include "console.h"

void DebugConsole(void *argv,uint16_t argc)
{

}



