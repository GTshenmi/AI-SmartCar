/*
 * include.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INCLUDE_H_
#define APP_INCLUDE_H_

#include "os.h"
#include "sys.h"
#include "usr.h"

#include "foo.h"
#include "init.h"
#include "app.h"

//#if defined(Chip) && Chip == TC264
//extern App_Cpu0 g_AppCpu0; /**< \brief CPU 0 global data */
//extern IfxCpu_mutexLock mutexCpu0InitIsOk;   /** CPU0 ��ʼ����ɱ�־λ  */
//#endif


#endif /* APP_INCLUDE_H_ */
