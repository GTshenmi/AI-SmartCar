/*
 * pwm.h
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */

#ifndef DRIVER_SYSDRIVER_PWM_H_
#define DRIVER_SYSDRIVER_PWM_H_

#include "LQ_GTM.h"

typedef enum
{
        TOM,ATOM,PwmDefaultConfig,
}pwm_source_t;

typedef struct
{
        IfxGtm_Tom_ToutMap Pin;
        unsigned long Freq;
        unsigned long Duty;
}tom_pwm_t;

typedef struct
{
        IfxGtm_Atom_ToutMap Pin;
        unsigned long Freq;
        unsigned long Duty;
}atom_pwm_t;

typedef struct
{
        void *Pin; /*IfxGtm_Atom_ToutMap,IfxGtm_Tom_ToutMap*/
        unsigned long Freq;
        unsigned long Duty;
        pwm_source_t pwm_source;
}pwmx_t;

typedef struct
{
        unsigned char (*Init)(pwmx_t *);
        unsigned char (*Write)(pwmx_t *,unsigned long duty);
        unsigned long MaxPwm;
        unsigned long MinPwm;
}spwm_m;

extern spwm_m PWMx;

#endif /* DRIVER_SYSDRIVER_PWM_H_ */
