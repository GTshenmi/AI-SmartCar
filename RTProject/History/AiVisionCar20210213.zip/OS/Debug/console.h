/*
 * console.h
 *
 *  Created on: 2021��1��16��
 *      Author: 936305695
 */

#ifndef OS_DEBUG_CONSOLE_H_
#define OS_DEBUG_CONSOLE_H_

#include "device.h"

void Task_DebugConsole(void *argv,uint16_t argc);

#endif /* OS_DEBUG_CONSOLE_H_ */
