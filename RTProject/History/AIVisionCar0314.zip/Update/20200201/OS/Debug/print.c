/*
 * print.c
 *
 *  Created on: 2021��1��2��
 *      Author: 936305695
 */
#include "print.h"
print_var_t var =
{
    .b = 1000,
    .c = 'c',
    .d = 3.12,
    .f = 2.0,
    .i = 1,
    .l = 2000,
    .s = "str",
    .uc = 20,
    .ui = 500,
    .ul = 5000,
};

