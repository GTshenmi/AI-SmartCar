/*
 * element.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *          This file is for the special element.
 */
#include <element.h>
#include "include.h"


/*
 *       Condition A  Condition B       Y
 *           0            0             0
 *           0            1             1
 *           1            0             1
 *           1            1             0
 *
 *
 *           Y = A'B + AB' = A B
 * */
#define RightAngleJudgeCondition ((data->V_ESensorValue[0] >= 30.0) ^ (data->V_ESensorValue[1] >= 30.0))

#define CrossJudgeCondition      ((data->V_ESensorValue[0] >= 50.0) && (data->V_ESensorValue[1] >= 50.0))

//((data->V_ESensorValue[0] >= 30.0) || (data->V_ESensorValue[1] >= 30.0)) && (!((data->V_ESensorValue[0] >= 30.0) && (data->V_ESensorValue[1] >= 30.0)))

void LoseLine_Handler(data_t *data);
void Cycle_Handler(data_t *data);
void Cross_Handler(data_t *data);
void RightAngle_Handler(data_t *data);


float ElementDetermine(void *argv)
{
    data_t *data = (data_t *)argv;


    if(CrossJudgeCondition)
    {
        data->Element.Type = Cross;

        GLED.ON(GLED.Self);
    }
    else
    {
        GLED.OFF(GLED.Self);
    }

    if(RightAngleJudgeCondition && data->Element.Type != Cross)
    {
        //DebugBeepOn;
        //SetValueWLock(data->Element,Type,RightAngle);

        data->Element.Type = RightAngle;
    }

//    if(((data->H_ESensorValue[1] > 2 * data->H_ESensorValue[0]) || (data->H_ESensorValue[1] >= 2 * data->H_ESensorValue[2])) &&  (data->H_ESensorValue[1] >= 60.0))
//    {
//        SetValueWLock(data->Element,Type,Cross);
//    }

    return data->Element.Type * 1.0;

}

/*
 * @Brief:����Ԫ�ش����ӿں���
 * */
void SpecialElementHandler(void *argv)
{
    data_t *data = (data_t *)argv;


    switch(data->Element.Type)
    {
        case RightAngle:
            RightAngle_Handler(data);
            break;
        case Cross:
            Cross_Handler(data);
            break;
        default:
            break;
    }


//    if(data->TrackingState == LoseLine)
//    {
//        //LoseLine_Handler(data);
//    }
//    else
//    {
//        switch(data->Element.Type)
//        {
//            case RightAngle:
//                RightAngle_Handler(data);
//                break;
//            case Cross:
//                Cross_Handler(data);
//                break;
//            default:
//                break;
//        }
//    }

}

void Cross_Handler(data_t *data)
{
    cycle_state_t cycleState = CC_Wait;

    switch(cycleState)
    {
        case CC_Wait:

            if(data->Element.Type == Cycle)
                cycleState = CC_Confirm;
            break;

        case CC_Confirm:    //ȷ���ǻ���
            
            
            Lock(data->Element);

            break;

        case CC_In:         //����뻷

            break;

        case CC_Tracking:   //��������Ѱ��

            break;
        case CC_Out:        //����

            cycleState = CC_Wait;
            Unlock(data->Element);
            data->Element.Type = None;
            break;
        default:

            break;
    }
}

void Cycle_Handler(data_t *data)
{

}

void RightAngle_Handler(data_t *data)
{
    static rightangle_state_t rightAngleState = RA_Wait;

    static sint32_t rightAngleCount = 0;

    switch(rightAngleState)
    {
        case RA_Wait:
            if(data->Element.Type == RightAngle)
            {
                rightAngleState = RA_Confirm;
            }
            break;

        case RA_Confirm:

            if(RightAngleJudgeCondition)
            {
                rightAngleState = RA_Tracking;

                rightAngleCount = 50;

                DebugBeepOn;
            }

            break;

        case RA_Tracking:

            data->Bias = fsign(data->V_ESensorValue[0] - data->V_ESensorValue[1]) * 100.0;

            rightAngleCount--;

            if((rightAngleCount <= 0) && (data->V_ESensorValue[0] <=20.0 && data->V_ESensorValue[1] <= 20.0) && (data->H_ESensorValue[0] >=20.0 ||data->H_ESensorValue[1] >=20.0|| data->H_ESensorValue[2] >= 20.0))
            {
                rightAngleState = RA_Out;
            }

            break;

        case RA_Out:

            DebugBeepOff;
            rightAngleState = RA_Wait;
            Unlock(data->Element);
            data->Element.Type = None;

            break;

    }


}




void LoseLine_Handler(data_t *data)
{
    static loseline_state_t loseLineState = LL_Wait;

    //float weight[10] = {0.2,0.2,0.2,0.1,0.1,0.05,0.05,0.04,0.03,0.03};

    float *eSensorData = EQueue.Gets(&data->EQueue,0,NULL,0,7);

    float hESensorValue[3];
    float vESensorValue[2];

    hESensorValue[0] = eSensorData[1];
    hESensorValue[1] = eSensorData[3];
    hESensorValue[2] = eSensorData[5];

    //vESensorValue[0] == eSensorData[0];
    //vESensorValue[1] = eSensorData[6];


    

    float bias = 0.0;

    int lossLineCount = 0;

    switch(loseLineState)
    {
        case LL_Wait:
            if(data->TrackingState == LoseLine)
            {
                loseLineState = LL_Lose;
            }
            break;
        case LL_Lose:

            DebugBeepOn;

            Lock(data->Element);

            for(int i = 0 ; i < 10 ;)       //ȡ��ʷʮ�����ݼ�Ȩƽ��
            {
                float *_bias = EQueue.Gets(&data->EQueue,-i,NULL,7,8);
                float *_trackState = EQueue.Gets(&data->EQueue,-i,NULL,8,9);

                if(*_trackState == (float)LoseLine)
                {
                    lossLineCount++;
                }
                else
                { 
                    bias += *_bias;
                    i++;
                }
            }

            if(lossLineCount >= 10) //���߳���10���� 
            {
                sint32_t rightcount = 0;
                sint32_t leftcount = 0;
                sint32_t count = 0;

                for(int i = 0 ; i < 10;)
                {
                    float *_bias = EQueue.Gets(&data->EQueue,-i,NULL,7,8);
                    float *_trackState = EQueue.Gets(&data->EQueue,-i,NULL,8,9);

                    if(*_trackState != (float)LoseLine)
                    { 
                        if(*_bias >= 0.0)
                        {
                            rightcount++;
                        }
                        else
                        {
                            leftcount--;
                        }

                        i++;
                    }
                    count++;

                    if(count >= 100)
                        break;


                }

                sint32_t angle = leftcount + rightcount;

                if(abs(angle) <= 2)
                {
                    bias = 0.0;
                }
                else
                {
                    bias = fsign(angle);
                }
            }
            else
            {
                bias /= 10.0;
            }      

            break;

        case LL_SearchLine:

            data->Bias = bias * 100.0;

            if(vESensorValue[0] <= 20.0 && vESensorValue[1] <= 20.0 && (hESensorValue[0] >= 40.0 || hESensorValue[1] >= 40.0 || hESensorValue[2] >= 40.0))
            {
                loseLineState = LL_Searched; 
            }
            break;

        case LL_Searched:

            loseLineState = LL_Wait;
            data->TrackingState = Normal_Tracking;

            Unlock(data->Element);

            DebugBeepOff;

            break;

        case LL_Undefined:default:

            break;
    }
}

