/*Generate By Python3.7 Env. Time:2021-03-31 21:51:43.582807*/

/*
 * NNParameter.h
 *
 *  Created on: 2021��3��28��
 *      Author: 936305695
 */

#ifndef APP_USR_NEURALNETWORK_NNPARAMETER_H_
#define APP_USR_NEURALNETWORK_NNPARAMETER_H_

extern double W0[7][140];

extern double W1[140][100];

extern double W2[100][40];

extern double W3[40][1];

extern double B0[140];

extern double B1[100];

extern double B2[40];

extern double B3[1];


#endif /* APP_USR_NEURALNETWORK_NNPARAMETER_H_ */