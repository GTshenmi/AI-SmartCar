/*
 * datacollection.h
 *
 *  Created on: 2021��7��21��
 *      Author: 936305695
 */

#ifndef APP_USR_DATACOLLECTION_H_
#define APP_USR_DATACOLLECTION_H_


#include "sys.h"

void HowToNameThisFunc(void *argv);


#endif /* APP_USR_DATACOLLECTION_H_ */
