/*
 * gpio.c
 *
 *  Created on: 2020��12��3��
 *      Author: 936305695
 */
#include <gpio.h>

unsigned char GPIOx_Init(gpio_t *gpio)
{
    if(!gpio->Is_Shield)
        PIN_InitConfig(gpio->Pin,gpio->Mode,gpio->State);
    else
        return 1;

    return 0;
}
unsigned char GPIOx_Read(gpio_t *gpio)
{
    if(!gpio->Is_Shield)
        return PIN_Read(gpio->Pin);
    else
        return 1;

    return 0;
}
unsigned char GPIOx_Write(gpio_t *gpio,unsigned char state)
{
    if(!gpio->Is_Shield)
        PIN_Write(gpio->Pin,gpio->State);
    else
        return 1;

    return 0;
}
sgpio_m GPIOx =
{
        .Init = GPIOx_Init,
        .Read = GPIOx_Read,
        .Write = GPIOx_Write,
};

