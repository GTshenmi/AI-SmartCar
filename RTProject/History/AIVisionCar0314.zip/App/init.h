/*
 * init.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INIT_H_
#define APP_INIT_H_

void Core0_Init(void);

#endif /* APP_INIT_H_ */
