/*
 * console.h
 *
 *  Created on: 2021��1��16��
 *      Author: 936305695
 */

#ifndef OS_DEBUG_CONSOLE_H_
#define OS_DEBUG_CONSOLE_H_

void Task_DebugConsole(void);

#endif /* OS_DEBUG_CONSOLE_H_ */
