#ifndef __CAMERA_ALGORITHM_H_
#define __CAMERA_ALGORITHM_H_

#include "sys.h"

#endif