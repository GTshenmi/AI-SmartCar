/*
 * resource_config.c
 *
 *  Created on: 2020��12��8��
 *      Author: 936305695
 */
#include "resource_config.h"

adc_resource_t ADC_Resources[12];

gpio_resource_t GPIO_Resources[20];

pwm_resource_t PWM_Resources[3];

enc_resource_t ENC_Resources[2];

tim_resource_t TIM_Resources[2];
uart_resource_t UART_Resources[2];
spi_resource_t SPI_Resources[2];

