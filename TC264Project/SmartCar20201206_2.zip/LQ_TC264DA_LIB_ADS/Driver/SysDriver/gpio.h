/*
 * gpio.h
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */

#ifndef DRIVER_USRDRIVER_GPIO_H_
#define DRIVER_USRDRIVER_GPIO_H_

#include "LQ_GPIO.h"
#include "stdbool.h"

typedef enum
{
    GPIO_Input,GPIO_Output
}gpio_dir_t;
typedef struct
{
        /*Reversed for GPIOx*/
        GPIO_Name_t Pin;
        IfxPort_Mode Mode;
        unsigned char State;
        bool Is_Shield;
}gpio_t;

typedef struct
{
        unsigned char (*Init)(gpio_t *);
        unsigned char (*InitExti)(gpio_t *,IfxPort_InputMode);
        unsigned char (*SetDir)(gpio_t *,gpio_dir_t);
        unsigned char (*Read)(gpio_t *);
        unsigned char (*Write)(gpio_t *,unsigned char state);
        unsigned char (*Reverse)(gpio_t *);
}sgpio_m;


extern sgpio_m GPIOx;

#endif /* DRIVER_USRDRIVER_GPIO_H_ */
