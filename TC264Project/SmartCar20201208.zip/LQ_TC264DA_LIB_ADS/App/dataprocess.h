/*
 * dataprocess.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_DATAPROCESS_H_
#define APP_DATAPROCESS_H_





#endif /* APP_DATAPROCESS_H_ */
