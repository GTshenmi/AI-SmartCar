/*
 * element.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_ELEMENT_H_
#define APP_ELEMENT_H_

#include "os.h"



#endif /* APP_ELEMENT_H_ */
