/*
 * spi.h
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_SPI_H_
#define DRIVER_SYSDRIVER_SPI_H_

#include "LQ_SPI.h"
#include "LQ_QSPI.h"

typedef enum
{
     SPI = 2,
     QSPI = 3,
}spi_source_t;

typedef struct
{
        unsigned int     SPIn;
        unsigned int     ClkPin;
        unsigned int     MisoPin;
        unsigned int     MosiPin;
        unsigned int     CsPin;
        unsigned char     Mode;
        spi_source_t Spi_Source;
        unsigned long BaudRate;
}spix_t;

typedef struct
{
        unsigned char (*Init)(spix_t *);
        unsigned char (*ReadWriteBytes)(spix_t *,unsigned char *txData, unsigned char *rxData, unsigned short len);
}sspi_m;

extern sspi_m SPIx;



#endif /* DRIVER_SYSDRIVER_SPI_H_ */
