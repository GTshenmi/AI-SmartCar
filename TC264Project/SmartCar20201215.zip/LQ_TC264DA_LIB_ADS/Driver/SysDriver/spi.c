/*
 * spi.c
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */
#include "spi.h"

unsigned char SPIx_Init(spix_t *spi)
{
    if(spi->Spi_Source == SPI)
    {
        SPI_InitConfig(spi->ClkPin,spi->MisoPin,spi->MosiPin,spi->CsPin,spi->BaudRate);
    }
    else if(spi->Spi_Source == QSPI)
    {
        QSPI_InitConfig(spi->ClkPin,spi->MisoPin,spi->MosiPin,spi->CsPin,spi->BaudRate,spi->Mode);
    }
    else
        return 1;
    return 0;
}

unsigned char SPIx_ReadWriteBytes(spix_t *spi,unsigned char *txData, unsigned char *rxData, unsigned short len)
{
    if(spi->Spi_Source == SPI)
    {
        SPI_ReadWriteNByte(spi->SPIn,txData,rxData,len);
    }
    else if(spi->Spi_Source == QSPI)
    {
        QSPI_ReadWriteNByte(spi->SPIn,txData,rxData,len);
    }
    else
        return 1;
    return 0;
}

sspi_m SPIx =
{
        .Init = SPIx_Init,
        .ReadWriteBytes = SPIx_ReadWriteBytes,
};

