/*
 * wirelessserial.c
 *
 *  Created on: 2021��1��19��
 *      Author: 936305695
 */
#include "wirelessserial.h"


void WirelessSerial_Init(struct wireless_serial *self)
{

}


