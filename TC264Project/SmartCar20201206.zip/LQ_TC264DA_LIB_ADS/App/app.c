/*
 * app.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *      This file is the top file of the whole project.
 *      function in this file is to be executed in the main function or the interrupt function.
 */
#include "app.h"
#include "include.h"

/*
 * @Brief:loop in the interrupt
 * */
void InterruptLoop()
{
    DataCollection();
    DataPreProcess();
    NeuralNetworkReasoning();
    short angle = CalculateServoAngle();
    short speed = CalculateMotorSpeed();
    SpecialElementCorrection(&speed,&angle);

    Motor.SetSpeed(Motor.Self,speed);
    Servo.SetAngle(Servo.Self,angle);
}
/*
 * @Brief:loop in the CPU0_Main
 * */
void CPU0_MainLoop()
{

}
/*
 * @Brief:loop in the CPU1_Main
 * */
void CPU1_MainLoop()
{

}
/*
 * @Brief:Data Collection
 * */
void DataCollection()
{
    for(int i = 0 ; i < 5 ; i++)
        ESensor[i].Read(ESensor[i].Self);
}
/*
 * @Brief:Data format and Range Unity
 * */
void DataPreProcess()
{

}
/*
 * @Brief:Use Neural Network to reason the Long-Term forward-looking data
 * */
void NeuralNetworkReasoning()
{

}
/*
 * @Brief:Calculate for the angle of Servo
 * */
short CalculateServoAngle()
{
    return 0;
}
/*
 * @Brief:Calculate for the Speed of Motor
 * */
short CalculateMotorSpeed()
{
    return 0;
}
/*
 * @Brief:Adjust Speed and Angle for Special Element
 * */
void SpecialElementCorrection(signed short *speed,signed short *angle)
{

}



