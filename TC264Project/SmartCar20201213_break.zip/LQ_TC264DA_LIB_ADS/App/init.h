/*
 * init.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INIT_H_
#define APP_INIT_H_

#include "os.h"

void SmartCarSystemInit();

/*CCU DMA EEPROM EMEM FFT GPSR QSPI SOFTIIC SPI STM UART*/

#endif /* APP_INIT_H_ */
