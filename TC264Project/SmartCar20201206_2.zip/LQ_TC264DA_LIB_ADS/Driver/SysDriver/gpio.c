/*
 * gpio.c
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */
#include <gpio.h>

unsigned char GPIOx_Init(gpio_t *gpio)
{
    if(!gpio->Is_Shield)
        PIN_InitConfig(gpio->Pin,gpio->Mode,gpio->State);
    else
        return 1;

    return 0;
}
unsigned char GPIOx_InitExti(gpio_t *gpio,IfxPort_InputMode mode)
{
    PIN_Exti(gpio->Pin,mode);
    PIN_ExtiEnable(gpio->Pin,true);
    return 0;
}


unsigned char GPIOx_Read(gpio_t *gpio)
{
    if(!gpio->Is_Shield)
        return PIN_Read(gpio->Pin);
    else
        return 1;

    return 0;
}
unsigned char GPIOx_Write(gpio_t *gpio,unsigned char state)
{
    if(!gpio->Is_Shield)
        PIN_Write(gpio->Pin,gpio->State);
    else
        return 1;

    return 0;
}

unsigned char GPIOx_Reverse(gpio_t *gpio)
{
    PIN_Reverse(gpio->Pin);
    return 0;
}

unsigned char GPIOx_SetDir(gpio_t *gpio,gpio_dir_t dir)
{
    PIN_Dir(gpio->Pin,dir);
    return 0;
}
sgpio_m GPIOx =
{
        .Init = GPIOx_Init,

        .SetDir = GPIOx_SetDir,
        .Read = GPIOx_Read,
        .Write = GPIOx_Write,
        .Reverse = GPIOx_Reverse,
};

