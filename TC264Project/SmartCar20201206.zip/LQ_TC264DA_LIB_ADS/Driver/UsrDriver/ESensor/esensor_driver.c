/*
 * esensor_driver.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */
#include "esensor_driver.h"

static unsigned ADCMidFilter(struct esensor *self);

unsigned short ESensorInit(struct esensor *self)
{
    ADCx.Init(self->AdcDevice);
    return 0;
}

unsigned short ESensorRead(struct esensor *self)
{
    return self->Cache = self->Filter(self,self->FilterBuf,self->FilterBufLen,ADCMidFilter(self));
}

unsigned short ESensorFilter(struct esensor *self,unsigned short *FilterBuf,unsigned short len,unsigned short new_data)
{
    for(int i = 0;i < len-1 ;i++)
        FilterBuf[i] = FilterBuf[i+1];
    FilterBuf[len-1] = new_data;

    unsigned short result = 0;
    for(int i = 0;i < len ;i++)
    {
        result += FilterBuf[i];
    }
    result /= len;

    return result;
}
static unsigned ADCMidFilter(struct esensor *self)
{
    unsigned short i,j,k,tmp;
    //1.ȡ3��A/Dת�����
    i = ADCx.Read(self->AdcDevice);
    j = ADCx.Read(self->AdcDevice);
    k = ADCx.Read(self->AdcDevice);
    //2.ȡ��ֵ
    if (i > j)
    {
        tmp = i; i = j; j = tmp;
    }
    if (k > j)
        tmp = j;
    else if(k > i)
        tmp = k;
    else
        tmp = i;

    return tmp;
}
esensor_t ESensor[5] =
{
    [0] = {
            .Init = ESensorInit,
            .Read = ESensorRead,
            .Filter = ESensorFilter,
            .Self = &ESensor[0],
    },
    [1] = {
            .Init = ESensorInit,
            .Read = ESensorRead,
            .Filter = ESensorFilter,
            .Self = &ESensor[1],
    },
    [2] = {
            .Init = ESensorInit,
            .Read = ESensorRead,
            .Filter = ESensorFilter,
            .Self = &ESensor[2],
    },
    [3] = {
            .Init = ESensorInit,
            .Read = ESensorRead,
            .Filter = ESensorFilter,
            .Self = &ESensor[3],
    },
    [4] = {
            .Init = ESensorInit,
            .Read = ESensorRead,
            .Filter = ESensorFilter,
            .Self = &ESensor[4],
    },


};



