/*
 * enc.c
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */
#include <enc.h>

unsigned char ENCx_Init(enc_t *enc)
{
    ENC_InitConfig(enc->InputPin,enc->DirPin);
    return 0;
}
signed short ENCx_Read(enc_t *enc)
{
    return ENC_GetCounter(enc->InputPin);
}

senc_m ENCx =
{
        .Init = ENCx_Init,
        .Read = ENCx_Read,
};



