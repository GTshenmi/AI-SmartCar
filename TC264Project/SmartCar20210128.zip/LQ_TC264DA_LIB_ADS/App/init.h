/*
 * init.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INIT_H_
#define APP_INIT_H_

void Core0_Init();

void Core1_Init();

#endif /* APP_INIT_H_ */
