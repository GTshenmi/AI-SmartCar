/*
 * console.c
 *
 *  Created on: 2021��1��16��
 *      Author: 936305695
 */
void Task_DebugConsole(void)
{

}



