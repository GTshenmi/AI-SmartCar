/*
 * servo.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_SERVO_SERVO_DRIVER_H_
#define DRIVER_USRDRIVER_SERVO_SERVO_DRIVER_H_

#include "sys_driver.h"

typedef struct
{
      int handle;
}servo_usr_extern_para_t; //para only for close cycle ctrl

typedef struct servo_ctrl
{
        unsigned char (*Init)(struct servo_ctrl *self);
        unsigned short (*SetAngle)(struct servo_ctrl *self,signed short angle);
        float (*GetAngle)(struct servo_ctrl *self);

        pwm_t *PwmDevice;
        enc_t *MPUDevice;

        /*Servo Close Loop Control Function,It Support Re-Definition,Keep It NULL if  MPU6050 or other Angle Sensor not exist.*/
        unsigned short (*CtrlStrategy)(signed short target_angle,signed short actual_angle,servo_usr_extern_para_t *);

        signed short MaxAngle;
        signed short MinAngle;

        unsigned short PwmValue;
        unsigned short PwmCentValue;

        bool Is_Run;

        struct servo_ctrl *Self;
        servo_usr_extern_para_t *Usr;

}servo_ctrl_t;

extern servo_ctrl_t Servo;



#endif /* DRIVER_USRDRIVER_SERVO_SERVO_DRIVER_H_ */
