/*
 * ctrlsys.h
 *
 *  Created on: 2020��12��28��
 *      Author: 936305695
 */

#ifndef APP_CTRLSYS_H_
#define APP_CTRLSYS_H_

#include "include.h"

typedef enum
{
    CtrlSys_Running,CtrlSys_Stopped,CtrlSys_Sleeping,
}sys_state_t;
typedef struct sctrlsysdata
{
        signed short angle;
}sctrlsysdata_t;

typedef struct mctrlsysdata
{
        signed short speed;
}mctrlsysdata_t;

typedef struct unit
{
        void (*Run)(struct unit *self,void *data);
        void (*Start)(struct unit *self);
        void (*Stop)(struct unit *self);
        void (*Sleep)(struct unit *self,uint32_t time);
        void (*WakeUp)(struct unit *self);
        sys_state_t State;
        struct unit *Self;
}unit_t;

typedef struct sctrlsys
{
        void (*Init)(struct sctrlsys *self);
        void (*Run)(struct sctrlsys *self);
        void (*Start)(struct sctrlsys *self);
        void (*Stop)(struct sctrlsys *self);
        void (*Sleep)(struct sctrlsys *self,uint32_t time);
        void (*WakeUp)(struct sctrlsys *self);
        sys_state_t State;
        unit_t SensorUnit;
        unit_t DecisionUnit;
        unit_t ExecutionUnit;
        sctrlsysdata_t *Data;
        struct sctrlsys *Self;
        bool Is_Corrected;
}sctrlsys_t;

typedef struct mctrlsys
{
        void (*Init)(struct mctrlsys *self);
        void (*Run)(struct mctrlsys *self);
        void (*Start)(struct mctrlsys *self);
        void (*Stop)(struct mctrlsys *self);
        void (*Sleep)(struct mctrlsys *self,uint32_t time);
        void (*WakeUp)(struct mctrlsys *self);
        sys_state_t State;
        unit_t SensorUnit;
        unit_t DecisionUnit;
        unit_t ExecutionUnit;

        mctrlsysdata_t *Data;

        struct mctrlsys *Self;
        bool Is_Corrected;
}mctrlsys_t;

extern sctrlsysdata_t ServoSysData;
extern sctrlsys_t ServoSys;

extern mctrlsysdata_t MotorSysData;
extern mctrlsys_t MotorSys;

#endif /* APP_CTRLSYS_H_ */
