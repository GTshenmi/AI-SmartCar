/*
 * lcd_driver.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_LCD_LCD_DRIVER_H_
#define DRIVER_USRDRIVER_LCD_LCD_DRIVER_H_

#if 1

#if 1
#include "LQ_GPIO.h"
#include "LQ_STM.h"
#include "stdio.h"
#include <stdarg.h>
#include "stdbool.h"

#define SUPPORT_UART 0

#define USING_HARDWARE_CONTROLER 0

/*                      !important!                         */
#define LCD_delayus(us) delayus(us);            //Delay function interface->delay x us
#define LCD_delayms(ms) delayms(ms);            //Delay function interface->delay x ms
/*                      !important!                         */

/*                      !SPI Control!                           */
#if !USING_HARDWARE_CONTROLER

#define LCD_WriteByte       LCD_SoftWareWriteByte //send byte function interface->LCD_SoftWareWriteByte
#define LCD_WriteWord       LCD_SoftWareWriteWord //send word function interface->LCD_SoftWareWriteWord
#define LCD_WriteCmd    LCD_SoftWareWriteCmd    //send command function interface->LCD_SoftWareWriteCmd
#define _GPIO_WritePin PIN_Write

#define LCD_DC_GPIO   P00_0  //E11->GPIO_B0_15
#define LCD_RST_GPIO    P00_0    //B13->GPIO_B1_10
#define LCD_SDA_GPIO    P00_0
#define LCD_SCL_GPIO    P00_0
#define LCD_CS_GPIO   P00_0

#define LCD_DC(x)       ((x==1)?_GPIO_WritePin(LCD_DC_GPIO,1):_GPIO_WritePin(LCD_DC_GPIO,0))
#define LCD_RST(x)  ((x==1)?_GPIO_WritePin(LCD_RST_GPIO,1):_GPIO_WritePin(LCD_RST_GPIO,0))
#define LCD_SDA(x)  ((x==1)?_GPIO_WritePin(LCD_SDA_GPIO,1):_GPIO_WritePin(LCD_SDA_GPIO,0))
#define LCD_SCL(x)  ((x==1)?_GPIO_WritePin(LCD_SCL_GPIO,1):_GPIO_WritePin(LCD_SCL_GPIO,0))
#define LCD_CS(x)   ((x==1)?_GPIO_WritePin(LCD_CS_GPIO,1):_GPIO_WritePin(LCD_CS_GPIO,0))


#else

#define LCD_WriteByte   LCD_HardWareWriteByte //send byte function interface->LCD_SoftWareWriteByte
#define LCD_WriteWord   LCD_HardWareWriteWord //send word function interface->LCD_SoftWareWriteWord
#define LCD_WriteCmd  LCD_HardWareWriteCmd  //send command function interface->LCD_SoftWareWriteCmd

#endif
/*                      !SPI Control!                           */

volatile typedef enum
{
        RED     =0xf800,
        GREEN   =0x07e0,
        LIGHTBLUE=0x87ff,
        BLUE        =0x001f,
        PURPLE  =0xf81f,
        YELLOW  =0xffe0,
        CYAN        =0x07ff,        //����ɫ
        ORANGE  =0xfc08,
        BLACK   =0x0000,
        WHITE   =0xffff,

}lcd_color_t;
typedef enum
{
        usingWriteXLine,
        usingNone,
}printstate_t;
typedef struct
{
        unsigned char Type; //���壬��δд����
        unsigned char Hight;
        unsigned char Width;
        lcd_color_t Color;
        lcd_color_t Backcolor;
        printstate_t PrintState;
}lcd_font_t;
typedef struct
{
        unsigned int x;
        unsigned int y;
}cursor_t;
typedef struct
{
        lcd_color_t Color;
        unsigned char Width;
        unsigned char Interval;
}XLine_t;
typedef struct
{
        void (*HalfLine)(const char *format,...);
        void (*Line)(const char *format,...);
        void (*XLine)(unsigned char row,const char *format,...);
}write_t;

typedef struct
{
        void (*Char)(unsigned char row,unsigned char col,unsigned char ch,lcd_color_t color);
        void (*Num)(unsigned char row,unsigned char col,long num,lcd_color_t color);
        void (*Chinese)(void);
        void (*Str)(unsigned char row,unsigned char col,unsigned char *str,lcd_color_t color);
}show_t;

typedef struct
{
        void (*Point)(unsigned char xs,unsigned char ys,lcd_color_t color);
        void (*Hline)(unsigned char xs,unsigned char ys,unsigned char len,unsigned char width,lcd_color_t color);
        void (*Vline)(unsigned char xs,unsigned char ys,unsigned char len,unsigned char width,lcd_color_t color);
        void (*Line)(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);
        void (*Sqr)(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);
        void (*Circle)(unsigned char x,unsigned char y,unsigned char r,lcd_color_t color);
        void (*Pic)(unsigned char x,unsigned char y,unsigned char w,unsigned char h,unsigned char *ppic);
}draw_t;

typedef struct
{
        void (*SendByte)(unsigned char data);
        void (*SendWord)(unsigned short data);
        void (*SendCmd)(unsigned char cmd);
        void (*Test)(void);
        void (*AddrReset)(void);
        void (*SetPos)(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye);
        void (*Clear)(lcd_color_t color);
        void (*Fill)(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);
        void (*SetCursor)(unsigned short x,unsigned short y);
        void (*SetBackGroundColor)(lcd_color_t color);
        void (*SetFontSize)(unsigned char width,unsigned char hight);
        void (*SetFontColor)(lcd_color_t color);
        void (*SetFontBackColor)(lcd_color_t color);
        void (*SetXLineColor)(lcd_color_t color);
        void (*SetXLineWidth)(unsigned char width);
        void (*SetXLineInterval)(unsigned char interval);
        void (*SetXLineVal)(lcd_color_t color,unsigned char width,unsigned char interval);
}debug_t;

typedef struct
{
        unsigned int Hight;
        unsigned int Width;
        bool Type;                  //������ ֻ֧����������������ûд
        cursor_t Cursor;
        lcd_color_t Backgroundcolor;
        XLine_t XLine;
        lcd_font_t Font;
        void (*Init)(void);
        void (*DeInit)(void);
        show_t Show;
        draw_t Draw;
        write_t Write;
        debug_t Debug;
        bool IsPrint;
}lcd_ctrl_t;


extern lcd_ctrl_t LCD;

void LCD_Init(void);
void LCD_DeInit(void);

#if !USING_HARDWARE_CONTROLER
void LCD_SoftWareWriteByte(unsigned char data);
void LCD_SoftWareWriteWord(unsigned short data);
void LCD_SoftWareWriteCmd(unsigned char cmd);
#else
void LCD_HardWareSPIInit(unsigned short baudrate);
void LCD_HardWareWriteByte(unsigned char data);
void LCD_HardWareWriteWord(unsigned short data);
void LCD_HardWareWriteCmd(unsigned char cmd);
#endif
void LCD_AddrReset(void);
void LCD_SetPos(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye);
void LCD_SetBackGroundColor(lcd_color_t color);
void LCD_SetFontSize(unsigned char width,unsigned char hight); //����printf �Լ�write����ʹ��
void LCD_SetFontColor(lcd_color_t color);                       //����printf �Լ�write����ʹ��
void LCD_SetFontBackColor(lcd_color_t color);                               //����printf �Լ�write����ʹ��
void LCD_SetCursor(unsigned short x,unsigned short y);                      //����printf �Լ�write����ʹ��
void LCD_SetXLineColor(lcd_color_t color);                      // ������WriteXLine����
void LCD_SetXLineWidth(unsigned char width);                                // ������WriteXLine����
void LCD_SetXLineInterval(unsigned char interval);                  // ������WriteXLine����
void LCD_SetXLineVal(lcd_color_t color,unsigned char width,unsigned char interval);     // ������WriteXLine����
void LCD_Clear(lcd_color_t color);
void LCD_Fill(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);

void LCD_DrawPoint(unsigned char xs,unsigned char ys,lcd_color_t color);
void LCD_DrawHLine(unsigned char xs,unsigned char ys,unsigned char len,unsigned char width,lcd_color_t color);
void LCD_DrawVLine(unsigned char xs,unsigned char ys,unsigned char len,unsigned char width,lcd_color_t color);
void LCD_DrawLine(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);
void LCD_DrawSqr(unsigned char xs,unsigned char ys,unsigned char xe,unsigned char ye,lcd_color_t color);
void LCD_DrawCircle(unsigned char x,unsigned char y,unsigned char r,lcd_color_t color);
void LCD_DrawPic(unsigned char x,unsigned char y,unsigned char w,unsigned char h,unsigned char *ppic);

void LCD_ShowChar(unsigned char row,unsigned char col,unsigned char ch,lcd_color_t color);
void LCD_ShowNum(unsigned char row,unsigned char col,long num,lcd_color_t color);
void LCD_ShowChinese(void);
void LCD_ShowStr(unsigned char row,unsigned char col,unsigned char *str,lcd_color_t color);

void LCD_WriteHalfLine(const char *format,...);
void LCD_WriteLine(const char *format,...);
void LCD_WriteXLine(unsigned char row,const char *format,...);

void LCD_Test(void);
/*                                                                                              �����                                                                                                 */
extern unsigned char Font_code8[][6];
/*                                                                                              �����                                                                                                 */
#endif
#endif


#endif /* DRIVER_USRDRIVER_LCD_LCD_DRIVER_H_ */
