/*
 * servo.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */
#include <servo_driver.h>
#include "sys_driver.h"

unsigned char ServoxInit(struct servo_ctrl *self)
{
    PWMx.Init(self->PwmDevice);
    return 0;
}

unsigned short SetServoAngle(struct servo_ctrl *self,signed short angle)
{
    if(angle > self->MaxAngle)
        angle = self->MaxAngle;
    else if(angle < self->MinAngle)
        angle = self->MinAngle;

    float actual_angle = self->GetAngle(self);

    self->DataProcess(&angle,(signed short *)&actual_angle,self->Usr);
    self->PwmValue = self->CtrlStrategy(angle,(signed short)actual_angle,self->Usr);

    PWMx.Write(self->PwmDevice,self->PwmValue);

    return self->PwmValue;
}

float GetServoAngle(struct servo_ctrl *self)
{
    return self->PwmValue * 1.0;
}

unsigned short ServoDefaultCtrlStrategy(signed short target_angle,signed short actual_angle,servo_usr_extern_para_t *usr)
{
    return target_angle;
}
unsigned short ServoDefaultDataProcess(signed short *target_angle,signed short *actual_angle,servo_usr_extern_para_t *usr)
{
    return 0;
}

servo_ctrl_t Servo =
{
        .Init = ServoxInit,
        .SetAngle = SetServoAngle,
        .GetAngle = GetServoAngle,
        .CtrlStrategy = ServoDefaultCtrlStrategy,
        .DataProcess = ServoDefaultDataProcess,
        .Self = &Servo,
        .Usr = &SUsr,
};
servo_usr_extern_para_t SUsr;

