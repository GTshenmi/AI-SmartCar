1.MCUXpresso-Config-Tools下载链接  可以自行选择电脑版本
https://www.nxp.com/support/developer-resources/software-development-tools/mcuxpresso-software-and-tools/mcuxpresso-config-tools-pins-clocks-peripherals:MCUXpresso-Config-Tools?&tab=Design_Tools_Tab


2.IAR8.4下载地址  https://netstorage.iar.com/SuppDB/Protected/PRODUPD/013861/EWARM-CD-8401-21539.exe
    MDK 下载地址  http://www2.keil.com/mdk5

3.使用说明
例程均在Example文件夹下
注意 RT1064只支持IAR8.3以上版本  IAR例程不能有中文路径
注意 RT1064只支持IAR8.3以上版本  IAR例程不能有中文路径
注意 RT1064只支持IAR8.3以上版本  IAR例程不能有中文路径




4.程序说明
例程均在Example 文件夹下，所有例程公用一套库文件，所以将库文件属性设置为只读模式，需要修改可自行修改文件属性
因为IAR例程不能有中文路径，所以例程都是用英文命名的
1.LED灯测试例程
2.按键测试例程
3.按键外部中断测试例程
4.PIT定时器中断测试例程
5.串口测试
6.串口 printf 打印测试
7.gpt 程序计时器 测试
8.systick 系统计时器测试
9.oled 显示测试
10.tft1.8 寸屏 显示测试
11.adc 采集测试
12.硬件产生随机数测试
13.看门狗测试
14.窗口看门狗测试
15.读取芯片温度测试
16.flexPWM 生成10路PWM测试
17.电机测试
18.舵机测试
19.编码器测试
20.qtmr 产生PWM测试
21.qtmr 带方向计数测试
22.mpu6050或者icm20602 软硬件iic读取原始数据测试
23.龙邱九轴 软硬件iic读取原始数据测试
24.VL53 激光测距模块 软硬件iic读取原始数据测试
25.HC-SR04 超声波测距模块 中断测试
26.icm20602 硬件spi读取原始数据测试
27.DMA 内存到内存传输测试
28.串口+DMA 空闲中断接收不定长数据帧测试
29.串口 发送到匿名上位机画正玄波
30.外部flash读写测试
31.CAN 测试例程
32.SD卡读写测试
33.互补融合滤波
34.卡尔曼滤波
35.OV7725 TFT18显示图像测试
36.OV7725 OLED屏幕显示测试
37.OV7725 上位机显示测试
38.神眼 TFT18显示测试
39.神眼 OLED屏幕上显示测试
40.神眼 上位机显示测试
41.拍照存卡测试例程
42.神眼 FLEXIO CAMERA TFT18显示测试
43.神眼 FLEXIO CAMERA OLED屏幕上显示测试
44.姿态解算测试
example 一个例子工程 可以基于改工程构建自己的程序


