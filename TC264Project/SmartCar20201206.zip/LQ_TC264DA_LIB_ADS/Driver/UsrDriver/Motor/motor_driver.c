/*
 * motor.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */
#include <motor_driver.h>
#include "sys_driver.h"

unsigned char MotorxInit(struct motor_ctrl *self)
{
    PWMx.Init(self->PwmDevice[0]);
    PWMx.Init(self->PwmDevice[1]);
    ENCx.Init(self->EncDevice);
    return 0;
}

unsigned short SetMotorSpeed(struct motor_ctrl *self,signed short speed)
{
    if(speed > self->MaxSpeed)
        speed = self->MaxSpeed;
    else if(speed < self->MinSpeed)
        speed = self->MinSpeed;

    signed short actual_speed = self->SpeedCache;

    self->DataProcess(&speed,&actual_speed,self->Usr);
    self->PwmValue = self->CtrlStrategy(speed,actual_speed,self->Usr);

    if(speed > 0)
    {
        PWMx.Write(self->PwmDevice[0],self->PwmValue);
        PWMx.Write(self->PwmDevice[1],0);
    }
    else
    {
        PWMx.Write(self->PwmDevice[0],0);
        PWMx.Write(self->PwmDevice[1],self->PwmValue);
    }

    return self->PwmValue;
}

signed short GetMotorSpeed(struct motor_ctrl *self)
{
    unsigned short speed = ENCx.Read(self->EncDevice);

    if(speed > self->MaxSpeed)
      speed = self->MaxSpeed;
    else if(speed < self->MinSpeed)
      speed = self->MinSpeed;

    return self->SpeedCache = speed;
}

unsigned short MotorDefaultCtrlStrategy(signed short target_speed,signed short actual_speed,motor_usr_extern_para_t *usr)
{
    return target_speed;
}
unsigned short MotorDefaultDataProcess(signed short *target_speed,signed short *actual_speed,motor_usr_extern_para_t *usr)
{
    return 0;
}

motor_ctrl_t Motor =
{
        .Init = MotorxInit,
        .SetSpeed = SetMotorSpeed,
        .GetSpeed = GetMotorSpeed,
        .CtrlStrategy = MotorDefaultCtrlStrategy,
        .DataProcess = MotorDefaultDataProcess,
        .Self = &Motor,
        .Usr = &MUsr,
};
motor_usr_extern_para_t MUsr;


