/*
 * enc.h
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */

#ifndef DRIVER_SYSDRIVERLQ_ENC_H_
#define DRIVER_SYSDRIVERLQ_ENC_H_

#include "LQ_GPT12_ENC.h"


typedef struct
{
        ENC_InputPin_t InputPin;
        ENC_DirPin_t DirPin;
}enc_t;
typedef struct
{
        unsigned char (*Init)(enc_t *);
        signed short (*Read)(enc_t *);
}senc_m;

extern senc_m ENCx;
#endif /* DRIVER_SYSDRIVERLQ_ENC_H_ */
