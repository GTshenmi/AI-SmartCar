/*
 * gpio.h
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */

#ifndef DRIVER_USRDRIVER_GPIO_H_
#define DRIVER_USRDRIVER_GPIO_H_

#include "LQ_GPIO.h"
#include "stdbool.h"

typedef enum
{
    GPIO_Input,GPIO_Output
}gpio_dir_t;
typedef struct
{
        /*Reversed for GPIOx*/
        GPIO_Name_t Pin;
        IfxPort_Mode Mode;
        unsigned char State;
        bool Is_Shield;
}gpiox_t;

typedef struct
{
        unsigned char (*Init)(gpiox_t *);
        unsigned char (*InitExti)(gpiox_t *,IfxPort_InputMode);
        unsigned char (*SetDir)(gpiox_t *,gpio_dir_t);
        unsigned char (*Read)(gpiox_t *);
        unsigned char (*Write)(gpiox_t *,unsigned char state);
        unsigned char (*Reverse)(gpiox_t *);
}sgpio_m;


extern sgpio_m GPIOx;

#endif /* DRIVER_USRDRIVER_GPIO_H_ */
