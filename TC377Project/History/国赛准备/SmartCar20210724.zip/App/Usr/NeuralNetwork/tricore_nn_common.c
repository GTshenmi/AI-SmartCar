/*
 * cmsis_nncommon.c
 *
 *  Created on: 2021��4��14��
 *      Author: 936305695
 */
#include <tricore_nn_common.h>

void ___foo__()
{

}



