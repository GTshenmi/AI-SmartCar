/*
 * app.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_USR_APP_H_
#define APP_USR_APP_H_

void Sensor_InterruptRun(void);
void Ctrl_InterruptRun(void);
void Core0_Main(void);
void Core1_Main(void);

#endif /* APP_USR_APP_H_ */
