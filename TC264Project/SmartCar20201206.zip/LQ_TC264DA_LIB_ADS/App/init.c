/*
 * init.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *          This file is for the initialization function.
 */

#include "init.h"
#include "include.h"

void SmartCarSystemInit()
{
    gpio_t test_io =
    {
            .Is_Shield = false,
            .Pin = P10_1,
            .Mode =IfxPort_Mode_outputOpenDrainGeneral,
            .State = 1,
    };
    GPIOx.Init(&test_io);
    GPIOx.Write(&test_io,0);

    adc_t test_adc = {
            .Channel = ADC0,
            .Freq = 10000,
    };
    ADCx.Init(&test_adc);
    unsigned int result = ADCx.Read(&test_adc);

    LCD.Write.XLine(0,"ADC:%u",result);

    pwm_t test_pwm =
    {
            .Pin =(void *) &IfxGtm_TOM0_11_TOUT63_P20_7_OUT,
            .Freq = 10000,
            .Duty = 50,
            .pwm_source = TOM,
    };

    PWMx.Init(&test_pwm);
    PWMx.Write(&test_pwm,50);

    enc_t test_enc =
    {
            .DirPin = ENC2_InPut_P33_7,
            .InputPin = ENC2_Dir_P33_6,

    };
    ENCx.Init(&test_enc);
    unsigned int speed = ENCx.Read(&test_enc);
    LCD.Write.XLine(1,"Speed:%u",speed);

    Motor.Init(Motor.Self);
    Motor.SetSpeed(Motor.Self,5000);


}

void InitDemo()
{
    gpio_t test_io =
    {
            .Is_Shield = false,
            .Pin = P10_1,
            .Mode =IfxPort_Mode_outputOpenDrainGeneral,
            .State = 1,
    };
    GPIOx.Init(&test_io);
    GPIOx.Write(&test_io,0);

    adc_t test_adc = {
            .Channel = ADC0,
            .Freq = 10000,
    };
    ADCx.Init(&test_adc);
    unsigned int result = ADCx.Read(&test_adc);

    LCD.Write.XLine(0,"ADC:%u",result);

    pwm_t test_pwm =
    {
            .Pin =(void *) &IfxGtm_TOM0_11_TOUT63_P20_7_OUT,
            .Freq = 10000,
            .Duty = 50,
    };

    PWMx.Init(&test_pwm);
    PWMx.Write(&test_pwm,50);

    enc_t test_enc =
    {
            .DirPin = ENC2_InPut_P33_7,
            .InputPin = ENC2_Dir_P33_6,

    };
    ENCx.Init(&test_enc);
    unsigned int speed = ENCx.Read(&test_enc);
    LCD.Write.XLine(1,"Speed:%u",speed);
}


