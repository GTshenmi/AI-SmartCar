#include "include.h"

IfxCpu_mutexLock mutexTFTIsOk = 0;   /* TFT18ʹ�ñ�־λ  */

int core1_main (void)
{
    SmartCarSys.Core1.Init();
    SmartCarSys.Core1.Run();
    return 0;
}
