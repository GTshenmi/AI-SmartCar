/*
 * pwm.h
 *
 *  Created on: 2020��12��3��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_PWM_H_
#define DRIVER_SYSDRIVER_PWM_H_

#include "LQ_GTM.h"
typedef enum
{
        TOM,ATOM,PwmDefaultConfig,
}pwm_source_t;

typedef struct
{
        IfxGtm_Tom_ToutMap Pin;
        unsigned long Freq;
        unsigned long Duty;
}tom_pwm_t;

typedef struct
{
        IfxGtm_Atom_ToutMap Pin;
        unsigned long Freq;
        unsigned long Duty;
}atom_pwm_t;

typedef struct
{
        void *Pin;
        unsigned long Freq;
        unsigned long Duty;
}pwm_t;

typedef struct
{
        unsigned char (*Init)(pwm_t *,pwm_source_t);
        unsigned char (*Write)(pwm_t *,unsigned long duty,pwm_source_t);
}spwm_m;

extern spwm_m PWM;

#endif /* DRIVER_SYSDRIVER_PWM_H_ */
