/*
 * camera.c
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */
#include "camera.h"

unsigned char Camera_Init(unsigned char fps)
{
    return 0;
}


