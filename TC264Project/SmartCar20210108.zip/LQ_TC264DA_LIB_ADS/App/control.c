/*
 * control.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *      This file is for motor and servo close-loop control.
 */
#include "control.h"
#include "include.h"

/*
 * @Brief:Motor Close Loop Control Function
 * @Output:PwmValue::unsigned short
 * @Attention:
 * */
unsigned short MotorCtrlStrategy(struct motor_ctrl *self,signed short target_speed,signed short actual_speed,void *usr)
{
    return 0;
}
/*
 * @Brief: Servo Close Loop Control Function(only for angle-cycle)
 * @output:PwmValue::unsigned short
 * @Attention:
 * */
unsigned short ServoCtrlStrategy(struct servo_ctrl *self,signed short target_angle,float actual_angle,void *usr)
{

    return 0;
}




