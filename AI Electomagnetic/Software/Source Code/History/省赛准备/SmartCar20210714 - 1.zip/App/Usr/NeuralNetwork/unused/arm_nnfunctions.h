/*
 * arm_nnfunctions.h
 *
 *  Created on: 2021��7��11��
 *      Author: 936305695
 */

#ifndef APP_USR_NEURALNETWORK_UNUSED_ARM_NNFUNCTIONS_H_
#define APP_USR_NEURALNETWORK_UNUSED_ARM_NNFUNCTIONS_H_

#include "nn_library.h"



#endif /* APP_USR_NEURALNETWORK_UNUSED_ARM_NNFUNCTIONS_H_ */
