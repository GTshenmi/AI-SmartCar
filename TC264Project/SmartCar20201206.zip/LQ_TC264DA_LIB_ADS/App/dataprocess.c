/*
 * dataprocess.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *      This file is for data process (motor and servo close-loop control).
 */
#include "dataprocess.h"
#include "include.h"

/*
 * @Brief: Motor Data Process Function before Close Loop Control Function
 * @output:
 *          target_speed
 *          actual_speed
 *          usr
 * @Attention: You can add input Parameter in the motor_usr_extern_para_t struct in Driver/UsrDriver/Motor/motor_driver.h,
 *             and you can change the value of input parameter in this function.
 * */

unsigned short MotorDataProcess(signed short *target_speed,signed short *actual_speed,motor_usr_extern_para_t *usr)
{
    return 0;
}

/*
 * @Brief: Servo Data Process Function before Close Loop Control Function
 * @output:
 *          target_angle
 *          actual_angle
 *          usr
 * @Attention: You can add input Parameter in the motor_usr_extern_para_t struct in Driver/UsrDriver/Servo/servo_driver.h,
 *              and you can change the value of input parameter in this function.
 * */
unsigned short ServoDataProcess(signed short *target_angle,signed short *actual_angle,servo_usr_extern_para_t *usr)
{
    return 0;
}

