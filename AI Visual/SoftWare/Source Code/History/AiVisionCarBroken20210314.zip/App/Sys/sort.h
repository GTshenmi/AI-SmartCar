/*
 * sort.h
 *
 *  Created on: 2021��1��18��
 *      Author: 936305695
 */

#ifndef APP_SYS_SORT_H_
#define APP_SYS_SORT_H_

void Bubble_Sort(float *data,int len);
void Quick_Sort(float arr[], int start, int end);


#endif /* APP_SYS_SORT_H_ */
