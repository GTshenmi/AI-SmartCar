/*
 * foo.h
 *
 *  Created on: 2021��1��22��
 *      Author: 936305695
 */

#ifndef APP_FOO_H_
#define APP_FOO_H_

#include "os.h"
#include "parameter.h"

#endif /* APP_FOO_H_ */
