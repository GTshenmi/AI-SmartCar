/*
 * init.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INIT_H_
#define APP_INIT_H_

void Core0_HardWareInit(void);
void Core0_SoftWareInit(void);

void Core1_HardWareInit(void);
void Core1_SoftWareInit(void);

void Core2_HardWareInit(void);
void Core2_SoftWareInit(void);

#endif /* APP_INIT_H_ */
