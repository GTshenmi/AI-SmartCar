/*
 * sysmath.h
 *
 *  Created on: 2021��1��26��
 *      Author: 936305695
 */

#ifndef APP_SYS_SYSMATH_H_
#define APP_SYS_SYSMATH_H_

#include "chipdatatype.h"

#define fsign(x) ((x) > 0.0 ?  1.0 : -1.0 )

float NormalizeFloat(float value,float max,float min);
float CalculateDistanceDifDivSum(float L1,float L2);
uint16_t FindMaxIndex(float *array,uint16_t len);

#endif /* APP_SYS_SYSMATH_H_ */
