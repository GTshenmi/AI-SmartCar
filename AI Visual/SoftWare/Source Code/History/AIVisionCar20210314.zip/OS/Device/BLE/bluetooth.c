/*
 * bluetooth.c
 *
 *  Created on: 2021��1��19��
 *      Author: 936305695
 */
#include "bluetooth.h"
#include "driver.h"

void Bluetooth_Init(struct bluetooth *self)
{

}
