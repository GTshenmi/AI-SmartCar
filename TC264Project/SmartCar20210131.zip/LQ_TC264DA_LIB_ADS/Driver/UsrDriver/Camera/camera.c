/*
 * camera.c
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */
#include "camera.h"

typedef char pixel_t;
typedef struct
{
        int resource;
}LQMT9V034_resource_t;
#define AT_DTCRAM_SECTION(x) x
typedef struct
{
        void *resource;
        void *ops;
}camera_device_handle_t;
#define CSI 0
typedef struct
{
        int csiBase;
}csi_resource_t;

char *LQMT9V034_ops;
char *csi_ops;
typedef  char csi_private_data_t;

#define kVIDEO_PixelFormatYUYV 1
#define kCAMERA_InterfaceGatedClock 1
#define kCAMERA_HrefActiveHigh 1
#define kCAMERA_DataLatchOnRisingEdge 1

typedef struct
{
      void *resource;
      void *ops;
      void *privateData;
}camera_receiver_handle_t;

//��������ͷ���ݻ�����
AT_DTCRAM_SECTION(volatile pixel_t csiFrameBuf[APP_CAMERA_FRAME_BUFFER_COUNT][APP_CAMERA_HEIGHT][APP_CAMERA_WIDTH]);


/* ����ͷʹ��Ӳ����Դ ����û���õ� */
static LQMT9V034_resource_t LQMT9V034Resource;

/* ����ͷ�������ýṹ�� */
camera_device_handle_t cameraDevice = {
    .resource = &LQMT9V034Resource,
    .ops = &LQMT9V034_ops,
};


/* CSI ������ؽṹ��. */
static csi_resource_t csiResource = {
    .csiBase = CSI,
};

static csi_private_data_t csiPrivateData;

camera_receiver_handle_t cameraReceiver = {
    .resource = &csiResource,
    .ops = &csi_ops,
    .privateData = &csiPrivateData,
};
typedef struct _camera_config
{
    int pixelFormat;    /*!< Pixel format. */
    uint8_t bytesPerPixel;               /*!< Byte per pixel. */
    uint32_t resolution;                 /*!< Resolution, see @ref video_resolution_t and @ref FSL_VIDEO_RESOLUTION. */
    uint16_t frameBufferLinePitch_Bytes; /*!< Frame buffer line pitch in bytes. */
    int interface;        /*!< Interface type. */
    uint32_t controlFlags;               /*!< Control flags, OR'ed value of @ref _camera_flags. */
    uint8_t framePerSec;                 /*!< Frame per second. */
} camera_config_t;

camera_config_t cameraConfig;   //����ͷ���ýṹ��
#define FSL_VIDEO_RESOLUTION(width, height) ((uint32_t)(width) | ((uint32_t)(height) << 16U))


camera_config_t cameraConfig = {
        .pixelFormat   = kVIDEO_PixelFormatYUYV,//kVIDEO_PixelFormatYUYV,//kVIDEO_PixelFormatBGR565,
        .bytesPerPixel = APP_BPP,//   ÿ�����ص㼸������
        .resolution = FSL_VIDEO_RESOLUTION(APP_CAMERA_WIDTH, APP_CAMERA_HEIGHT), //�ֱ���
        .frameBufferLinePitch_Bytes = APP_CAMERA_WIDTH * APP_BPP,                //�м��
        .interface     = kCAMERA_InterfaceGatedClock,                            //������ӿ�����
        .controlFlags = APP_CAMERA_CONTROL_FLAGS,
        .framePerSec   = CAMERA_FPS,                                             //fps
    };


/**
  * @brief    CSI�жϷ�����
  *
  * @param
  *
  * @return
  *
  * @note
  *
  * @example
  *
  * @date     2019/6/24 ����һ
  */
void CSI_IRQHandler(void)
{
    //CSI_DriverIRQHandler();
}


/**
  * @brief    ����ͷCSI�ӿڳ�ʼ��
  *
  * @param
  *
  * @return
  *
  * @note
  *
  * @example
  *
  * @date     2019/6/24 ����һ
  */
void CSI_PinsInit(void)
{
//    CLOCK_EnableClock(kCLOCK_Iomuxc);
//
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_04_CSI_PIXCLK,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_06_CSI_VSYNC,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_07_CSI_HSYNC,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_08_CSI_DATA09,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_09_CSI_DATA08,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_10_CSI_DATA07,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_11_CSI_DATA06,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B1_12_CSI_DATA05,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B0_09_CSI_DATA04,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B0_10_CSI_DATA03,0U);
//    IOMUXC_SetPinMux(IOMUXC_GPIO_AD_B0_11_CSI_DATA02,0U);
//
//    /* CSI MCLK select 120M. */
//   /*
//    * CSI clock source:
//    * 00 derive clock from osc_clk (24M)
//    * 01 derive clock from PLL2 PFD2
//    * 10 derive clock from pll3_120M
//    * 11 derive clock from PLL3 PFD1
//    */
//    CLOCK_SetMux(kCLOCK_CsiMux, 2);
//
//    CLOCK_SetDiv(kCLOCK_CsiDiv, 1);

}

uint8_t CSI_CameraInit(void *config)
{
//    /* �ֶ�����һ��IICֹͣ�źţ���ֹIIC���� */
    GPIOx.Init(Camera_SCK_GPIO); //J11, PIN_MODE_OUTPUT, 1
    GPIOx.Init(Camera_SDA_GPIO); //K11, PIN_MODE_OUTPUT, 1

    Camera_SDA(0);
    Systime.Delayms(5);
    Camera_SDA(1);
    Systime.Delayms(5);

    //IIC_InitConfig(LPI2C1, 50000);
    CSI_PinsInit();

#if defined(Chip) && Chip == RT1064
    CAMERA_RECEIVER_Init(&cameraReceiver, &cameraConfig, NULL, NULL);  //��ʼ��csi

    CAMERA_DEVICE_Init(&cameraDevice, &cameraConfig);                  //��ʼ������ͷ

    CAMERA_DEVICE_Start(&cameraDevice);                                //�������

    for (uint32_t i = 0; i < APP_CAMERA_FRAME_BUFFER_COUNT; i++)       //����֡�������ύ������������
    {
        CAMERA_RECEIVER_SubmitEmptyBuffer(&cameraReceiver, (uint32_t)(csiFrameBuf[i]));
    }

    CAMERA_RECEIVER_Start(&cameraReceiver);   // ��������camera����
#endif
    Systime.Delayms(100);
    return 0;
}

