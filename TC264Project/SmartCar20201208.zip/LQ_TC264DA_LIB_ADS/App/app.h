/*
 * app.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_APP_H_
#define APP_APP_H_

#include "sys_driverlq.h"
#include "usr_driver.h"
#include "sys_driver.h"

void DataCollection(void);
void DataPreProcess(void);
void NeuralNetworkReasoning(void);
short CalculateServoAngle(void);
short CalculateMotorSpeed(void);
void SpecialElementCorrection(signed short *speed,signed short *angle);
void InterruptLoop(void);
void CPU0_MainLoop(void);
void CPU1_MainLoop(void);

#endif /* APP_APP_H_ */
