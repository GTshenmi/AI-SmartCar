/*
 * neuralnetwork.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_USR_NEURALNETWORK_NEURALNETWORK_H_
#define APP_USR_NEURALNETWORK_NEURALNETWORK_H_

#include "sys.h"
#include "NNLib.h"

void NeuralNetworkInit(void *data);
void NeuralNetworkReasoning(void *data);

#endif /* APP_USR_NEURALNETWORK_NEURALNETWORK_H_ */
