/*
 * pwm.c
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */
#include <pwm.h>
#include <SysDriverLQ/LQ_GTM.h>

unsigned char PWMx_Init(pwm_t *pwm)
{
    pwm_source_t pwm_source = pwm->pwm_source;
    if(pwm_source == TOM)
    {
        IfxGtm_Tom_ToutMap *pin =(IfxGtm_Tom_ToutMap *) pwm->Pin;
        TOM_PWM_InitConfig(*pin,pwm->Duty,pwm->Freq);
    }
    else if(pwm_source == ATOM)
    {
        IfxGtm_Atom_ToutMap *pin =(IfxGtm_Atom_ToutMap *) pwm->Pin;
        ATOM_PWM_InitConfig(*pin,pwm->Duty,pwm->Freq);
    }
    else
        return 0;
    return 0;
}
unsigned char PWMx_Write(pwm_t *pwm,unsigned long duty)
{
    if(duty > PWMx.MaxPwm)
        duty = PWMx.MaxPwm;
    else if(duty < PWMx.MinPwm)
        duty = PWMx.MinPwm;

    pwm_source_t pwm_source = pwm->pwm_source;
    if(pwm_source == TOM)
    {
        IfxGtm_Tom_ToutMap *pin =(IfxGtm_Tom_ToutMap *) pwm->Pin;
        TOM_PWM_SetDuty(*pin,pwm->Duty,pwm->Freq);
    }
    else if(pwm_source == ATOM)
    {
        IfxGtm_Atom_ToutMap *pin =(IfxGtm_Atom_ToutMap *) pwm->Pin;
        ATOM_PWM_SetDuty(*pin,pwm->Duty,pwm->Freq);
    }
    else
        return 0;
    return 0;
}
spwm_m PWMx =
{
        .Init = PWMx_Init,
        .Write = PWMx_Write,
        .MaxPwm = 10000,
        .MinPwm = -10000,
};



