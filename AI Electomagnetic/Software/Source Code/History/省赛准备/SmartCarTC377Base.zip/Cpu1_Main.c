#include "include.h"


int core1_main (void)
{
    SCore1.Init();
    SCore1.Run();
    return 0;
}
