/*
 * uart.c
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */
#include "uart.h"

unsigned char UARTx_Init(uartx_t *uart)
{
    UART_InitConfig(uart->RxPin,uart->TxPin,uart->BaudRate);
    return 0;
}

unsigned char UARTx_WriteByte(uartx_t *uart,unsigned char byte)
{
    UART_PutChar(uart->UARTn,byte);
    return 0;
}
unsigned char UARTx_WriteString(uartx_t *uart,unsigned char *string,unsigned int len)
{
    for(int i = 0 ; i < len ; i++)
        UART_PutChar(uart->UARTn,string[i]);
    return 0;
}


unsigned char UARTx_ReadByte(uartx_t *uart)
{
    return UART_GetChar(uart->UARTn);
}
unsigned char UARTx_ReadString(uartx_t *uart,unsigned char *string,unsigned int len)
{
    for(int i = 0 ; i < len ; i++)
        string[i] = UART_GetChar(uart->UARTn);
    return 0;
}

unsigned char UARTx_Write(uartx_t *uart,const char *fmt,...)
{

    return 0;
}
unsigned char UARTx_Read(uartx_t *uart,const char *fmt,...)
{
    return 0;
}

unsigned char UARTx_WriteLine(uartx_t *uart,const char *fmt,...)
{

    UARTx_WriteByte(uart,'\n');
    return 0;
}
unsigned char UARTx_ReadLine(uartx_t *uart,const char *fmt,...)
{
    return 0;
}

suart_m UARTx =
{
        .Init = UARTx_Init,

        .WriteByte =UARTx_WriteByte ,
        .WriteString = UARTx_WriteString,
        .Write = UARTx_Write,
        .WriteLine = UARTx_WriteLine,

        .ReadByte = UARTx_ReadByte,
        .ReadString = UARTx_ReadString,
        .Read =  UARTx_Read,
        .ReadLine = UARTx_ReadLine,

};


