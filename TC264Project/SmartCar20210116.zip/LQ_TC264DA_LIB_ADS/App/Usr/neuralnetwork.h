/*
 * neuralnetwork.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_USR_NEURALNETWORK_H_
#define APP_USR_NEURALNETWORK_H_

#include "ctrlsys.h"
#include "smartcarsys.h"

void NeuralNetworkReasoning(void);

#endif /* APP_USR_NEURALNETWORK_H_ */
