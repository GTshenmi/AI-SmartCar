/*
 * adc.c
 *
 *  Created on: 2020��12��3��
 *      Author: 936305695
 */
#include <adc.h>

unsigned char ADCx_Init(adc_t *adc)
{
    ADC_InitConfig(adc->Channel,adc->Freq);
    return 0;
}
unsigned short ADCx_Read(adc_t *adc)
{
    return ADC_Read(adc->Channel);
}
sadc_m ADCx =
{
        .Init = ADCx_Init,
        .Read = ADCx_Read,
};






