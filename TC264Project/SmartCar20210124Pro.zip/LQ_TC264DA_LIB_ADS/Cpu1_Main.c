#include "include.h"

IfxCpu_mutexLock mutexTFTIsOk = 0;   /* TFT18ʹ�ñ�־λ  */

int core1_main (void)
{
    SCore1.Init();

    IfxCpu_releaseMutex(&SCore1.mutexCoreInitIsOk);
    while(!IfxCpu_acquireMutex(&SCore0.mutexCoreInitIsOk));

    SCore1.Run();
    while(1);

    return 0;
}
