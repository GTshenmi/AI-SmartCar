#include "include.h"

void core2_main(void)
{
    SCore2.Init();
    SCore2.Run();
}
