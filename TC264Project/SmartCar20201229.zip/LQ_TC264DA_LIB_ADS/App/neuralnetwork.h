/*
 * neuralnetwork.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_NEURALNETWORK_H_
#define APP_NEURALNETWORK_H_


#endif /* APP_NEURALNETWORK_H_ */
