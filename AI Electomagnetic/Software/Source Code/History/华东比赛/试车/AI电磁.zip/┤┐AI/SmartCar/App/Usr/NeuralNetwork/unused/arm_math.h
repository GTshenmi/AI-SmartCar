/*
 * arm_math.h
 *
 *  Created on: 2021��7��11��
 *      Author: 936305695
 */

#ifndef APP_USR_NEURALNETWORK_UNUSED_ARM_MATH_H_
#define APP_USR_NEURALNETWORK_UNUSED_ARM_MATH_H_





#endif /* APP_USR_NEURALNETWORK_UNUSED_ARM_MATH_H_ */
