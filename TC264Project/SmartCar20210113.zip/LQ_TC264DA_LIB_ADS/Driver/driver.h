/*
 * driver.h
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */

#ifndef DRIVER_DRIVER_H_
#define DRIVER_DRIVER_H_

#define TC264 0
#define TC377 1
#define RT1064 2
#define Other -1

#define Chip TC264

#include "sys_driver.h"
#include "usr_driver.h"



#endif /* DRIVER_DRIVER_H_ */
