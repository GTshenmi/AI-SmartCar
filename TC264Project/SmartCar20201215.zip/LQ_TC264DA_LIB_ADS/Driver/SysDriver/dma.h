/*
 * dma.h
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_DMA_H_
#define DRIVER_SYSDRIVER_DMA_H_

#include "LQ_DMA.h"

typedef struct
{
     unsigned long SrcStartAddr;
     unsigned long DstStartAddr;
     unsigned long Channel;
}dmax_t;

typedef struct
{
    unsigned char (*Init)(dmax_t *);
    unsigned char (*Start)(dmax_t *);
    unsigned char (*Stop)(dmax_t *);
}sdma_m;

extern sdma_m DMAx;

#endif /* DRIVER_SYSDRIVER_DMA_H_ */
