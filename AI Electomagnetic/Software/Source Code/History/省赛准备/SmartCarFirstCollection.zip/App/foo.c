/*
 * foo.c
 *
 *  Created on: 2021��1��22��
 *      Author: 936305695
  *   ��֪д�ĵĺ�����ʱ����
 */
#include "foo.h"
#include "include.h"

uint SaveParameterSD(float *LADC_Value,float *SADC_Value,float *Angle){
    char buffer[50];
    char* bufferPointer = buffer;

    for(uint8_t i = 0;i < MAX_LESENSOR_NUM;i++){
        bufferPointer += sprintf(bufferPointer,"%f ",LADC_Value[i]);
    }
    bufferPointer += sprintf(bufferPointer,"\n");

    for(uint8_t i = 0;i < MAX_SESENSOR_NUM;i++){
        bufferPointer += sprintf(bufferPointer,"%f ",SADC_Value[i]);
    }
    bufferPointer += sprintf(bufferPointer,"\n");

    bufferPointer += sprintf(bufferPointer,"%f",*Angle);
    bufferPointer += sprintf(bufferPointer,"\n");

    return SD.fastWrite("Parameter.txt",buffer);
//    char buffer[50];
//    char* bufferPointer = buffer;
//
//    for(uint8_t i = 0;i < MAX_LESENSOR_NUM;i++){
//        bufferPointer += sprintf(bufferPointer,"%u ",LADC_Value[i]);
//    }
//    bufferPointer += sprintf(bufferPointer,"\n");
//
//    for(uint8_t i = 0;i < MAX_SESENSOR_NUM;i++){
//        bufferPointer += sprintf(bufferPointer,"%u ",SADC_Value[i]);
//    }
//    bufferPointer += sprintf(bufferPointer,"\n");
//
//    bufferPointer += sprintf(bufferPointer,"%d",*Angle);
//    bufferPointer += sprintf(bufferPointer,"\n");
//
//    return SD.fastWrite("Parameter.txt",buffer);

}


