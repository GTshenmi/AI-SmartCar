/*
 * foo.h
 *
 *  Created on: 2021��1��22��
 *      Author: 936305695
 */

#ifndef APP_FOO_H_
#define APP_FOO_H_

void SaveAutoBootModeDataToExcel(void *data);
void ReadParameterFromSDCard(void *data);
void SaveParameterToSDCard(void *data);

#endif /* APP_FOO_H_ */
