/*
 * camera.c
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */
#include "camera.h"

uint8_t Camera_Init(uint8_t fps)
{
    return 0;
}


