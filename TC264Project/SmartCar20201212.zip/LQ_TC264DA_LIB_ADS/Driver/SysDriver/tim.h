/*
 * timer.h
 *
 *  Created on: 2020��12��12��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_TIM_H_
#define DRIVER_SYSDRIVER_TIM_H_

#include "stdbool.h"
#include "LQ_CCU6.h"
#include "LQ_STM.h"

typedef enum
{
        STM,CCU6
}timer_source_t;

typedef struct
{
        CCU6_t Ccu6;
        CCU6_Channel_t Channel;
}ccux_t;

typedef struct
{
        STM_t Stm;
        STM_Channel_t Channel;
}stm_t;

typedef struct
{
        int Timer;
        int Channel;
        unsigned long interrupt_interval;
        bool Enable_Interrupt;
        bool Is_Run;
        timer_source_t timer_source;
}timx_t;

typedef struct
{
        unsigned char (*Init)(timx_t *);
        unsigned char (*Start)(timx_t *);
        unsigned char (*Delay)(timx_t *,unsigned long us);
        unsigned long (*GetTime)(timx_t *);
        unsigned char (*DeInit)(timx_t *);
        unsigned char (*Stop)(timx_t *);
}stim_m;

extern stim_m TIMx;



#endif /* DRIVER_SYSDRIVER_TIM_H_ */
