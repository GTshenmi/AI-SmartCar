/*
 * ctrlsys.c
 *
 *  Created on: 2020��12��28��
 *      Author: 936305695
 */
#include "ctrlsys.h"
#include "include.h"

void UnitInit(struct unit *self);
void UnitWakeUpCallBack(void *argv,uint16_t argc);
void MotorCtrlSysWakeUpCallBack(void *argv,uint16_t argc);
void ServoCtrlSysWakeUpCallBack(void *argv,uint16_t argc);

void ServoCtrlSysRun(struct sctrlsys *self)
{
    if(self->State ==  CtrlSys_Running)
    {
        if(!self->Is_Corrected)
        {
            self->SensorUnit.Run(&self->SensorUnit,self->Data);
            self->DecisionUnit.Run(&self->DecisionUnit,self->Data);
        }

        self->ExecutionUnit.Run(&self->ExecutionUnit,self->Data);
    }
}
void ServoCtrlSysStart(struct sctrlsys *self)
{
    self->State = CtrlSys_Running;
}
void ServoCtrlSysStop(struct sctrlsys *self)
{
    self->State = CtrlSys_Stopped;
}
void ServoCtrlSysWakeUp(struct sctrlsys *self)
{
    if(self->State == CtrlSys_Sleeping)
        self->State = CtrlSys_Running;
}
void ServoCtrlSysWakeUpCallBack(void *argv,uint16_t argc)
{
    struct sctrlsys *self = (struct sctrlsys *)argv;
    self->WakeUp(self);
}
void ServoCtrlSysSleep(struct sctrlsys *self,uint32_t time)
{
    if(self->State == CtrlSys_Running)
    {
        self->State = CtrlSys_Sleeping;
        if(time != 0)
        {
            uint16_t id = os.softtimer.findFreeTimer();
            os.softtimer.start(id,SoftTimer_Mode_OneShot,time,0,ServoCtrlSysWakeUpCallBack,self,0);
        }
    }
}
void ServoCtrlSysInit(struct sctrlsys *self)
{
    UnitInit(&self->DecisionUnit);
    UnitInit(&self->ExecutionUnit);
    UnitInit(&self->SensorUnit);
    self->Run = ServoCtrlSysRun;
    self->Sleep = ServoCtrlSysSleep;
    self->Start = ServoCtrlSysStart;
    self->State = CtrlSys_Stopped;
    self->Stop = ServoCtrlSysStop;
    self->WakeUp = ServoCtrlSysWakeUp;
}

void MotorCtrlSysRun(struct mctrlsys *self)
{
    if(self->State ==  CtrlSys_Running)
    {
        if(!self->Is_Corrected)
        {
            self->SensorUnit.Run(&self->SensorUnit,self->Data);

            self->DecisionUnit.Run(&self->DecisionUnit,self->Data);
        }

        self->ExecutionUnit.Run(&self->ExecutionUnit,self->Data);
    }
}
void MotorCtrlSysStart(struct mctrlsys *self)
{
    self->State = CtrlSys_Running;
}
void MotorCtrlSysStop(struct mctrlsys *self)
{
    self->State = CtrlSys_Stopped;
}
void MotorCtrlSysWakeUp(struct mctrlsys *self)
{
    if(self->State == CtrlSys_Sleeping)
        self->State = CtrlSys_Running;
}
void MotorCtrlSysWakeUpCallBack(void *argv,uint16_t argc)
{
    struct mctrlsys *self = (struct mctrlsys *)argv;
    self->WakeUp(self);
}
void MotorCtrlSysSleep(struct mctrlsys *self,uint32_t time)
{
    if(self->State == CtrlSys_Running)
    {
        self->State = CtrlSys_Sleeping;
        if(time != 0)
        {
            uint16_t id = os.softtimer.findFreeTimer();
            os.softtimer.start(id,SoftTimer_Mode_OneShot,time,0,MotorCtrlSysWakeUpCallBack,self,0);
        }
    }
}
void MotorCtrlSysInit(struct mctrlsys *self)
{
    UnitInit(&self->DecisionUnit);
    UnitInit(&self->ExecutionUnit);
    UnitInit(&self->SensorUnit);
    self->Run = MotorCtrlSysRun;
    self->Sleep = MotorCtrlSysSleep;
    self->Start = MotorCtrlSysStart;
    self->State = CtrlSys_Stopped;
    self->Stop = MotorCtrlSysStop;
    self->WakeUp = MotorCtrlSysWakeUp;
}

void UnitDefauleRun(struct unit *self,void *data)
{
/*
 * @Example In MotorUnit:
 */
    /*
      mctrlsysdata_t* mdata = (mctrlsysdata_t*)data;
      .......
    */
/*
 * @Example In ServoUnit:
 */
    /*
      sctrlsysdata_t* sdata = (sctrlsysdata_t*)data;
      .......
    */

}
void UnitStart(struct unit *self)
{
    self->State = CtrlSys_Running;
}
void UnitSleep(struct unit *self,uint32_t time)
{
    if(self->State == CtrlSys_Running)
    {
        self->State = CtrlSys_Sleeping;
        if(time != 0)
        {
            uint16_t id = os.softtimer.findFreeTimer();
            os.softtimer.start(id,SoftTimer_Mode_OneShot,time,0,UnitWakeUpCallBack,self,0);
        }
    }
}
void UnitWakeUp(struct unit *self)
{
    if(self->State == CtrlSys_Sleeping)
        self->State = CtrlSys_Running;
}

void UnitWakeUpCallBack(void *argv,uint16_t argc)
{
    struct unit *self = (struct unit *)argv;
    self->WakeUp(self);
}


void UnitStop(struct unit *self)
{
    self->State = CtrlSys_Stopped;
}

void UnitInit(struct unit *self)
{
    self->Start = UnitStart;
    self->Run = UnitDefauleRun;
    self->Self = self;
    self->Sleep = UnitSleep;
    self->State = CtrlSys_Stopped;
    self->Stop = UnitStop;
    self->WakeUp = UnitWakeUp;

}


sctrlsysdata_t ServoSysData;
sctrlsys_t ServoSys =
{
        .Init = ServoCtrlSysInit,
        .Self = &ServoSys,
        .Data = &ServoSysData,
};

mctrlsysdata_t MotorSysData;
mctrlsys_t MotorSys =
{
        .Init = MotorCtrlSysInit,
        .Self = &MotorSys,
        .Data = &MotorSysData,
};


