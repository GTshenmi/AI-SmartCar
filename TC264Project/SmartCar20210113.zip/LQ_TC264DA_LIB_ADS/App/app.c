/*
 * app.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *      This file is the top file of the whole project.
 *      function in this file is to be executed in the main function or the interrupt function.
 */
#include <app.h>
#include "include.h"
/*
 * @Brief:loop in the interrupt
 * */
void Ctrl_InterruptRun()
{
    MotorSys.DecisionUnit.Run(MotorSys.DecisionUnit.Self,NULL);
    ServoSys.DecisionUnit.Run(ServoSys.DecisionUnit.Self,NULL);

    MotorSys.ExecutionUnit.Run(MotorSys.ExecutionUnit.Self,NULL);
    ServoSys.ExecutionUnit.Run(ServoSys.ExecutionUnit.Self,NULL);
}
/*
 * @Brief:loop in the interrupt
 * */
void Sensor_InterruptRun()
{
    MotorSys.SensorUnit.Run(MotorSys.SensorUnit.Self,NULL);
    ServoSys.SensorUnit.Run(ServoSys.SensorUnit.Self,NULL);
}

/*
 * @Brief:CPU0 Main Func
 * */
void Core0_Main()
{
    while(1)
    {
        UI.Update();
    }
}
/*
 * @Brief:CPU1 Main Func
 * */
void Core1_Main()
{

}


