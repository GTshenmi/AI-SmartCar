/*
 * spi.c
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */
#include "spi.h"

uint8_t SPIx_Init(spix_t *spi)
{
    if(spi->Spi_Source == SPI)
    {
        SPI_InitConfig(spi->ClkPin,spi->MisoPin,spi->MosiPin,spi->CsPin,spi->BaudRate);
    }
    else if(spi->Spi_Source == QSPI)
    {
        QSPI_InitConfig(spi->ClkPin,spi->MisoPin,spi->MosiPin,spi->CsPin,spi->BaudRate,spi->Mode);
    }
    else
        return 1;
    return 0;
}

uint8_t SPIx_ReadWriteBytes(spix_t *spi,uint8_t *txData, uint8_t *rxData, uint16_t len)
{
    if(spi->Spi_Source == SPI)
    {
        SPI_ReadWriteNByte(spi->SPIn,txData,rxData,len);
    }
    else if(spi->Spi_Source == QSPI)
    {
        QSPI_ReadWriteNByte(spi->SPIn,txData,rxData,len);
    }
    else
        return 1;
    return 0;
}

sspi_m SPIx =
{
        .Init = SPIx_Init,
        .ReadWriteBytes = SPIx_ReadWriteBytes,
};

