/*
 * usr.h
 *
 *  Created on: 2021��1��18��
 *      Author: 936305695
 */

#ifndef APP_USR_USR_H_
#define APP_USR_USR_H_

#include "parameter.h"
#include "control.h"
#include "dataprocess.h"
#include "element.h"
#include "neuralnetwork.h"
#include "camera_algorithm.h"

#endif /* APP_USR_USR_H_ */
