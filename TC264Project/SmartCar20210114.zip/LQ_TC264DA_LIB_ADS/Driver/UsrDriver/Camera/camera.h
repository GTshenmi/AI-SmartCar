/*
 * camera.h
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_CAMERA_CAMERA_H_
#define DRIVER_USRDRIVER_CAMERA_CAMERA_H_

#include "sys_driver.h"

uint8_t Camera_Init(uint8_t fps);



#endif /* DRIVER_USRDRIVER_CAMERA_CAMERA_H_ */
