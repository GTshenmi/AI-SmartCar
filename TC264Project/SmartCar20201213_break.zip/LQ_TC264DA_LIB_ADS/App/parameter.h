/*
 * parameter.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_PARAMETER_H_
#define APP_PARAMETER_H_

#include "os.h"



#endif /* APP_PARAMETER_H_ */
