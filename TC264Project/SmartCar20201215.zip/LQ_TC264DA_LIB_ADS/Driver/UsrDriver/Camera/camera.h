/*
 * camera.h
 *
 *  Created on: 2020��12��14��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_CAMERA_CAMERA_H_
#define DRIVER_USRDRIVER_CAMERA_CAMERA_H_

#include "sys_driver.h"

unsigned char Camera_Init(unsigned char fps);



#endif /* DRIVER_USRDRIVER_CAMERA_CAMERA_H_ */
