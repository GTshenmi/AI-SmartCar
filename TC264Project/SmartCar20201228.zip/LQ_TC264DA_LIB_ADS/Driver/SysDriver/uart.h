/*
 * uarn.h
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_UART_H_
#define DRIVER_SYSDRIVER_UART_H_

#include "LQ_UART.h"
#include "chipdatatype.h"

typedef enum
{
    UART = 0,
};
typedef struct
{
        UART_t    UARTn;
        UART_RX_t RxPin;
        UART_TX_t TxPin;
        uint32_t BaudRate;
}uartx_t;

typedef struct
{
        uint8_t (*Init)(uartx_t *);
        uint8_t (*WriteByte)(uartx_t *,uint8_t byte);
        uint8_t (*WriteString)(uartx_t *,uint8_t *string,uint32_t len);
        uint8_t (*Write)(uartx_t *,const sint8_t *fmt,...);/*Not Realized*/
        uint8_t (*WriteLine)(uartx_t *,const sint8_t *fmt,...);/*Not Realized*/

        uint8_t (*ReadByte)(uartx_t *);
        uint8_t (*ReadString)(uartx_t *,uint8_t *string,uint32_t len);
        uint8_t (*Read)(uartx_t *,const sint8_t *fmt,...);/*Not Realized*/
        uint8_t (*ReadLine)(uartx_t *,const sint8_t *fmt,...);/*Not Realized*/
}suart_m;

extern suart_m UARTx;

#endif /* DRIVER_SYSDRIVER_UART_H_ */
