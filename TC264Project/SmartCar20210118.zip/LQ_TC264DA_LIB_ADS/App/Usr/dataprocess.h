/*
 * dataprocess.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_USR_DATAPROCESS_H_
#define APP_USR_DATAPROCESS_H_

#include "sys.h"

void Motor_SensorUnitRun(struct unit *self,void *data);
void Motor_DecisionUnitRun(struct unit *self,void *data);

void Servo_SensorUnitRun(struct unit *self,void *data);
void Servo_DecisionUnitRun(struct unit *self,void *data);

unsigned char MotorCloseLoopReadData(struct motor_ctrl *self,void *usr);
unsigned char ServoCloseLoopReadData(struct servo_ctrl *self,void *usr);
unsigned short MotorCloseLoopDataProcess(struct motor_ctrl *self,signed short *target_speed,signed short *actual_speed,void *usr);
unsigned short ServoCloseLoopDataProcess(struct servo_ctrl *self,signed short *target_angle,float *actual_angle,void *usr);


#endif /* APP_USR_DATAPROCESS_H_ */
