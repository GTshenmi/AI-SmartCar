/*
 * include.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INCLUDE_H_
#define APP_INCLUDE_H_

#include "sys_driverlq.h"
#include "sys_driver.h"
#include "usr_driver.h"
#include "app.h"
#include "control.h"
#include "dataprocess.h"
#include "element.h"
#include "init.h"
#include "neuralnetwork.h"
#include "parameter.h"



#endif /* APP_INCLUDE_H_ */
