/*
 * parameter.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *
 *  @Brief:
 *          This file is for the definition of parameter.
 */
#include <parameter.h>
#include "include.h"

data_t Data[MAX_DATA_LEN] =
{
        [0] = {
                .Cache = 0,
        },
        [1] = {
                .Cache = 0,
        },
};
uint16_t data_pointer = 0;
