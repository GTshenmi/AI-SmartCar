/*
 * esensor_driver.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef DRIVER_USRDRIVER_ESENSOR_ESENSOR_DRIVER_H_
#define DRIVER_USRDRIVER_ESENSOR_ESENSOR_DRIVER_H_

#include "sys_driver.h"

typedef struct esensor
{
        adc_t *AdcDevice;
        unsigned short (*Init)(struct esensor *self);
        unsigned short (*Read)(struct esensor *self);
        unsigned short (*Filter)(struct esensor *self,unsigned short *FilterBuf,unsigned short len,unsigned short new_data);
        unsigned short Cache;
        unsigned short FilterBuf[10];
        unsigned short FilterBufLen;
        struct esensor *Self;
}esensor_t;

extern esensor_t ESensor[5];
#endif /* DRIVER_USRDRIVER_ESENSOR_ESENSOR_DRIVER_H_ */
