/*
 * uart.c
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */
#include "uart.h"

uint8_t UARTx_Init(uartx_t *uart)
{
    UART_InitConfig(uart->RxPin,uart->TxPin,uart->BaudRate);
    return 0;
}

uint8_t UARTx_WriteByte(uartx_t *uart,uint8_t byte)
{
    UART_PutChar(uart->UARTn,byte);
    return 0;
}
uint8_t UARTx_WriteString(uartx_t *uart,uint8_t *string,uint32_t len)
{
    for(int i = 0 ; i < len ; i++)
        UARTx_WriteByte(uart,string[i]);
    return 0;
}


uint8_t UARTx_ReadByte(uartx_t *uart)
{
    return UART_GetChar(uart->UARTn);
}
uint8_t UARTx_ReadString(uartx_t *uart,uint8_t *string,uint32_t len)
{
    for(int i = 0 ; i < len ; i++)
        string[i] = UARTx_ReadByte(uart);
    return 0;
}

uint8_t UARTx_Write(uartx_t *uart,const sint8_t *fmt,...)
{

    return 0;
}
uint8_t UARTx_Read(uartx_t *uart,const sint8_t *fmt,...)
{
    return 0;
}

uint8_t UARTx_WriteLine(uartx_t *uart,const sint8_t *fmt,...)
{

    UARTx_WriteByte(uart,'\n');
    return 0;
}
uint8_t UARTx_ReadLine(uartx_t *uart,const sint8_t *fmt,...)
{
    return 0;
}

suart_m UARTx =
{
        .Init = UARTx_Init,

        .WriteByte =UARTx_WriteByte ,
        .WriteString = UARTx_WriteString,
        .Write = UARTx_Write,
        .WriteLine = UARTx_WriteLine,

        .ReadByte = UARTx_ReadByte,
        .ReadString = UARTx_ReadString,
        .Read =  UARTx_Read,
        .ReadLine = UARTx_ReadLine,

};


