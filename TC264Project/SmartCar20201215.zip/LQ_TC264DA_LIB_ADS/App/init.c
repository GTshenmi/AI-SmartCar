/*
 * init.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *          This file is for the initialization function.
 */

#include "init.h"
#include "include.h"

void BEEP_OFF_TMR_CALLBACK(void *argc,unsigned short argv)
{
    BEEP.OFF(BEEP.Self);
}
void SmartCarSystemInit()
{
    os.init();
    Motor.Init(Motor.Self);
    Motor.SetSpeed(Motor.Self,5000);
    Servo.Init(Servo.Self);
    Servo.SetAngle(Servo.Self,5000);
    for(int i = 0;i<5;i++)
    {
        ESensor[i].Init(ESensor[i].Self);
    }
    LED.Init(LED.Self);


    Screen.Init(Screen.Self);

/*System Init Finished,BEEP ON*/
    BEEP.ON(BEEP.Self);
/*Set BEEP OFF 1 sec later*/
    os.softtimer.start(1,SoftTimer_Mode_OneShot,1000000,0,BEEP_OFF_TMR_CALLBACK,NULL,0);
}

void InitDemo()
{

}


