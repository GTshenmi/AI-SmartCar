/*
 * adc.h
 *
 *  Created on: 2020��12��3��
 *      Author: GT_shenmi
 */

#ifndef DRIVER_SYSDRIVER_ADC_H_
#define DRIVER_SYSDRIVER_ADC_H_

#include "LQ_ADC.h"

typedef struct
{
        ADC_Channel_t Channel;
        unsigned long Freq;
}adc_t;

typedef struct
{
        unsigned char (*Init)(adc_t *);
        unsigned short (*Read)(adc_t *);
        unsigned short MaxValue;
        unsigned short MinValue;
}sadc_m;

extern sadc_m ADCx;

#endif /* DRIVER_SYSDRIVER_ADC_H_ */
