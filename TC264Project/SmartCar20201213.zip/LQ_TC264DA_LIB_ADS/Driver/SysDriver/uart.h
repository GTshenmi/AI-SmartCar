/*
 * uarn.h
 *
 *  Created on: 2020��12��13��
 *      Author: 936305695
 */

#ifndef DRIVER_SYSDRIVER_UART_H_
#define DRIVER_SYSDRIVER_UART_H_

#include "LQ_UART.h"

typedef enum
{
    UART = 0,
};
typedef struct
{
        UART_t    UARTn;
        UART_RX_t RxPin;
        UART_TX_t TxPin;
        unsigned long BaudRate;
}uartx_t;

typedef struct
{
        unsigned char (*Init)(uartx_t *);
        unsigned char (*WriteByte)(uartx_t *,unsigned char byte);
        unsigned char (*WriteString)(uartx_t *,unsigned char *string,unsigned int len);
        unsigned char (*Write)(uartx_t *,const char *fmt,...);/*Not Realized*/
        unsigned char (*WriteLine)(uartx_t *,const char *fmt,...);/*Not Realized*/

        unsigned char (*ReadByte)(uartx_t *);
        unsigned char (*ReadString)(uartx_t *,unsigned char *string,unsigned int len);
        unsigned char (*Read)(uartx_t *,const char *fmt,...);/*Not Realized*/
        unsigned char (*ReadLine)(uartx_t *,const char *fmt,...);/*Not Realized*/
}suart_m;

extern suart_m UARTx;

#endif /* DRIVER_SYSDRIVER_UART_H_ */
