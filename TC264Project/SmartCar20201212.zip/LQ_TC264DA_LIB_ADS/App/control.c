/*
 * control.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *      This file is for motor and servo close-loop control.
 */
#include "control.h"
#include "include.h"

/*
 * @Brief:Motor Close Loop Control Function
 * @Output:PwmValue::unsigned short
 * @Attention: You Can add input Parameter in the motor_usr_extern_para_t struct in Driver/UsrDriver/Motor/motor_driver.h
 * */
unsigned short MotorCtrlStrategy(signed short target_speed,signed short actual_speed,motor_usr_extern_para_t *usr)
{
    return 0;
}
/*
 * @Brief: Servo Close Loop Control Function(only for dependment angle-cycle)
 * @output:PwmValue::unsigned short
 * @Attention: You Can add input Parameter in the servo_usr_extern_para_t struct in Driver/UsrDriver/Servo/servo_driver.h
 * */
unsigned short ServoCtrlStrategy(signed short target_angle,signed short actual_angle,servo_usr_extern_para_t *usr)
{
    return 0;
}




