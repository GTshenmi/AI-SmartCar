/*
 * include.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_INCLUDE_H_
#define APP_INCLUDE_H_

#include "os.h"
#include "ctrlsys.h"
#include "control.h"
#include "dataprocess.h"
#include "element.h"
#include "init.h"
#include "neuralnetwork.h"
#include "parameter.h"
#include "app.h"



#endif /* APP_INCLUDE_H_ */
