/*
 * element.h
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 */

#ifndef APP_USR_ELEMENT_H_
#define APP_USR_ELEMENT_H_

#include "ctrlsys.h"
#include "smartcarsys.h"

void SpecialElementCorrection(void *data);

#endif /* APP_USR_ELEMENT_H_ */
