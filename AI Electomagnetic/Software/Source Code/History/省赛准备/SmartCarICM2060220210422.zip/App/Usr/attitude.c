/*
 * attitude.c
 *
 *  Created on: 2021��4��18��
 *      Author: 936305695
 */
#include "attitude.h"

void AttitudeUpdate(axis_t *acc/*input*/,axis_t *gyro/*input*/,axis_t *mag/*not use*/,attitude_t *attitude/*output*/)
{
    
}

