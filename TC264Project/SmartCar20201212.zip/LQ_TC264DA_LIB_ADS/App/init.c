/*
 * init.c
 *
 *  Created on: 2020��12��6��
 *      Author: 936305695
 *  @Brief:
 *          This file is for the initialization function.
 */

#include "init.h"
#include "include.h"

void SmartCarSystemInit()
{

    Motor.Init(Motor.Self);
    Motor.SetSpeed(Motor.Self,5000);
    Servo.Init(Servo.Self);
    Servo.SetAngle(Servo.Self,5000);
    for(int i = 0;i<5;i++)
    {
        ESensor[i].Init(ESensor[i].Self);
    }
    LED.Init(LED.Self);

    Screen.Init(Screen.Self);

}

void InitDemo()
{

}


